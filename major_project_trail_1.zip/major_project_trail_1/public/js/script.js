// Example script for handling basic client-side interactions like form validation

document.addEventListener('DOMContentLoaded', function() {
    const form = document.querySelector('form');
    if (form) {
      form.addEventListener('submit', function(event) {
        const username = document.querySelector('#username');
        const password = document.querySelector('#password');
        if (username.value === "" || password.value === "") {
          event.preventDefault();
          alert("Please fill in all fields");
        }
      });
    }
  });
  