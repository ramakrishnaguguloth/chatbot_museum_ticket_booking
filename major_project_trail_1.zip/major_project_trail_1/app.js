const express = require("express");
const mysql = require("mysql2");
const bcrypt = require("bcryptjs");
const session = require("express-session");
const Razorpay = require("razorpay");
const bodyParser = require("body-parser");
require("dotenv").config();
const nodemailer = require("nodemailer");

const app = express();
const port = 3000;

// Database connection
const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "password",
    database: "museum_db",
});

db.connect((err) => {
    if (err) throw err;
    console.log("MySQL Connected!");
});

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static("public"));
app.use(
    session({
        secret: "secret",
        resave: true,
        saveUninitialized: true,
    })
);
app.set("view engine", "ejs");

// Razorpay setup
const razorpay = new Razorpay({
    key_id: "YOUR_RAZORPAY_KEY_ID",
    key_secret: "YOUR_RAZORPAY_KEY_SECRET",
});

// Routes
app.get("/", (req, res) => {
    res.render("index");
});

app.get("/register", (req, res) => {
    res.render("register");
});
app.get("/about", (req, res) => {
    res.render("about");
});
app.post("/register", (req, res) => {
    const { name, email, password } = req.body;
    const hashedPassword = bcrypt.hashSync(password, 8);

    const query = "INSERT INTO users (name, email, password) VALUES (?, ?, ?)";
    db.query(query, [name, email, hashedPassword], (err, result) => {
        if (err) throw err;
        res.redirect("/login");
    });
});

app.get("/login", (req, res) => {
    res.render("login");
});

app.post("/login", (req, res) => {
    const { email, password } = req.body;

    const query = "SELECT * FROM users WHERE email = ?";
    db.query(query, [email], (err, result) => {
        if (err) throw err;

        if (result.length > 0 && bcrypt.compareSync(password, result[0].password)) {
            console.log(result[0]);
            req.session.user = result[0];
            res.redirect("/landing");
        } else {
            console.log(result[0]);
            res.send("Invalid email or password");
        }
    });
});
app.get('/contact', (req, res) => {
    res.render('contact'); // This will render contact.ejs
  });
  app.post('/submitContact', (req, res) => {
    const { name, email, message } = req.body;
    // You can process the contact form data here (e.g., save to a database or send an email)
    console.log('Name:', name);
    console.log('Email:', email);
    console.log('Message:', message);
  
    // Redirect to a thank you page or back to the contact page
    res.redirect('/thankyou'); // Or you can render a success message
  });
  app.get('/thankyou', (req, res) => {
    res.render('thankyou'); // Create a thankyou.ejs page for confirmation
  });
app.get("/landing", (req, res) => {
    if (!req.session.user) return res.redirect("/login");
    res.render("landing", { user: req.session.user });
});



app.get("/logout", (req, res) => {
    req.session.destroy();
    res.redirect("/login");
});

app.get("/chatbot", (req, res) => {
    if (!req.session.user) return res.redirect("/login");
    res.render("chatbot", { user: req.session.user });
});

app.post("/create-order", async (req, res) => {
    const { amount } = req.body;
    const options = {
        amount: amount * 100, // Razorpay expects amount in paise
        currency: "INR",
    };

    try {
        const order = await razorpay.orders.create(options);
        res.json(order);
    } catch (err) {
        res.status(500).send("Error creating order");
    }
});

app.post("/book-ticket", (req, res) => {
    const { date, adults, children, amount, payment_id } = req.body;
    const user_id = req.session.user.id;
    const user_email = req.session.user.email; // Get user's email from session

    const query =
        "INSERT INTO tickets (user_id, date, adults, children, amount, payment_id) VALUES (?, ?, ?, ?, ?, ?)";
    db.query(query, [user_id, date, adults, children, amount, payment_id], async (err, result) => {
        if (err) {
            console.error("Error booking ticket:", err);
            return res.status(500).send("Error booking ticket");
        }

        // Send confirmation email
        const transporter = nodemailer.createTransport({
            service: "gmail",
            auth: {
                user: process.env.EMAIL_USER,
                pass: process.env.EMAIL_PASS
            },
        });

        const mailOptions = {
            from: process.env.EMAIL_USER,
            to: user_email,
            subject: "Museum Ticket Booking Confirmation",
            text: `Hello,\n\nYour museum ticket has been successfully booked.\n\n📅 Date: ${date}\n👤 Adults: ${adults}\n👶 Children: ${children}\n💰 Total Amount: $${amount}\n\nEnjoy your visit!\n\nThank you!`,
        };

        try {
            await transporter.sendMail(mailOptions);
            console.log(`Confirmation email sent to ${user_email}`);
            res.send("Ticket booked successfully! A confirmation email has been sent.");
        } catch (emailErr) {
            console.error("Error sending email:", emailErr);
            res.send("Ticket booked, but failed to send confirmation email.");
        }
    });
});


app.post("/send-email", (req, res) => {
    const { date, adults, children, amount } = req.body;

    // Get user email from session
    if (!req.session.user) {
        return res.status(401).json({ message: "User not logged in." });
    }
    
    const userEmail = req.session.user.email;

    // Configure Nodemailer transporter
    const transporter = nodemailer.createTransport({
        service: "gmail",
        auth: {
            user: process.env.EMAIL_USER,
            pass: process.env.EMAIL_PASS,
        },
    });

    // Email content
    const mailOptions = {
        from: process.env.EMAIL_USER,
        to: userEmail, // Send to the actual user
        subject: "Museum Ticket Booking Confirmation",
        text: `Your booking is confirmed!\n\nDate: ${date}\nAdults: ${adults}\nChildren: ${children}\nTotal Amount: $${amount}\n\nEnjoy your visit!`,
    };

    // Send email
    transporter.sendMail(mailOptions, (err, info) => {
        if (err) {
            console.error("Email Error:", err);
            return res.status(500).json({ message: "Failed to send email." });
        }
        console.log("Email sent:", info.response);
        res.json({ message: "Confirmation email sent!" });
    });
});
app.post("/book-ticket", (req, res) => {
    const { date, adults, children, amount } = req.body;

    if (!req.session.user) {
        return res.status(401).json({ message: "User not logged in." });
    }

    const user_id = req.session.user.id;

    // Insert booking details into the 'tickets' table
    const query = "INSERT INTO tickets (user_id, date, adults, children, amount) VALUES (?, ?, ?, ?, ?)";

    db.query(query, [user_id, date, adults, children, amount], (err, result) => {
        if (err) {
            console.error("Database Error:", err);
            return res.status(500).json({ message: "Error booking ticket." });
        }

        // Fetch user's email from the database
        db.query("SELECT email FROM users WHERE id = ?", [user_id], (err, userResult) => {
            if (err || userResult.length === 0) {
                console.error("User Fetch Error:", err);
                return res.status(500).json({ message: "Booking successful, but email failed." });
            }

            const userEmail = userResult[0].email;

            // Nodemailer transporter configuration
            const transporter = nodemailer.createTransport({
                service: "gmail",
                auth: {
                    user: process.env.EMAIL_USER,
                    pass: process.env.EMAIL_PASS,
                },
            });

            // Email content
            const mailOptions = {
                from: process.env.EMAIL_USER,
                to: userEmail, // Send to the actual user
                subject: "Museum Ticket Booking Confirmation",
                text: `Your booking is confirmed!\n\nDate: ${date}\nAdults: ${adults}\nChildren: ${children}\nTotal Amount: $${amount}\n\nEnjoy your visit!`,
            };

            // Send the confirmation email
            transporter.sendMail(mailOptions, (err, info) => {
                if (err) {
                    console.error("Email Error:", err);
                    return res.status(500).json({ message: "Ticket booked, but email failed." });
                }

                console.log("Email sent:", info.response);
                res.json({
                    message: "Your tickets are booked successfully! 🎟️ Check your email for details.",
                });
            });
        });
    });
});
app.get("/profile", (req, res) => {
    if (!req.session.user) {
        return res.redirect("/login");
    }

    const user_id = req.session.user.id;

    // Fetch user's booked tickets from the 'tickets' table
    const query = "SELECT * FROM tickets WHERE user_id = ?";
    db.query(query, [user_id], (err, result) => {
        if (err) {
            console.error("Error fetching tickets:", err);
            return res.status(500).send("Error fetching tickets.");
        }

        // Render profile page with user data and booked tickets
        res.render("profile", {
            user: req.session.user,
            tickets: result,  // Send tickets data to profile page
        });
    });
});



app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});